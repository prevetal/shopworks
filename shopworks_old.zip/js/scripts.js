// Ширина окна для ресайза
BODY = document.getElementsByTagName('body')[0]


document.addEventListener('DOMContentLoaded', function () {
	// Бегущая строка
	let blockTitle = document.querySelector('.block_title .swiper')

	if (blockTitle) {
		new Swiper('.block_title .swiper', {
			loop: true,
			speed: 25000,
			autoplay: {
			  delay: 1,
			  disableOnInteraction: true
			},
			watchSlidesProgress: true,
			slideActiveClass: 'active',
			slideVisibleClass: 'visible',
			spaceBetween: 0,
			slidesPerView:'auto',
			allowTouchMove: false
		})
	}


	// Steps
	stepsSliders = []

	const steps = document.querySelectorAll('.steps .swiper')

	steps.forEach(function (el, i) {
		el.classList.add('steps_s' + i)

		let options = {
			loop: false,
			speed: 500,
			watchSlidesProgress: true,
			slideActiveClass: 'active',
			slideVisibleClass: 'visible',
			spaceBetween: 20,
			slidesPerView: 'auto',
			simulateTouch: false,
			on: {
				init: swiper => setHeight(swiper.el.querySelectorAll('.step')),
				resize: swiper => {
					let steps = swiper.el.querySelectorAll('.step')

					steps.forEach(el => el.style.height = 'auto')

					setHeight(steps)
				}
			}
		}

		stepsSliders.push(new Swiper('.steps_s' + i, options))
	})


	// Страница проекта - Моб. слайдер
	let mobProjectSlider = document.querySelector('.mob_project_info .swiper')

	if (mobProjectSlider) {
		new Swiper('.mob_project_info .swiper', {
			loop: true,
			speed: 500,
			autoplay: {
			  delay: 3000,
			  disableOnInteraction: true
			},
			watchSlidesProgress: true,
			slideActiveClass: 'active',
			slideVisibleClass: 'visible',
			spaceBetween: 0,
			slidesPerView:'auto',
			pagination: {
				el: '.swiper-pagination',
				type: 'bullets',
				clickable: true,
				bulletActiveClass: 'active'
			},
		})
	}


	// Галерея проекта
	$('.project_gallery .wheelSlider-container').wheelSlider({
		items: 5,
		dots: false,
		arrowPrevHtml: '<svg class="icon"><use xlink:href="images/sprite.svg#ic_arr_hor"></use></svg>',
		arrowNextHtml: '<svg class="icon"><use xlink:href="images/sprite.svg#ic_arr_hor"></use></svg>'
	})


	// Аккордион
	$('body').on('click', '.accordion .accordion_item .head', function(e) {
		e.preventDefault()

		const $item = $(this).closest('.accordion_item'),
			$accordion = $(this).closest('.accordion')

		if ($item.hasClass('active')) {
			$item.removeClass('active').find('.data').slideUp(300)
		} else {
			$accordion.find('.accordion_item').removeClass('active')
			$accordion.find('.data').slideUp(300)

			$item.addClass('active').find('.data').slideDown(300)
		}
	})


	// Табы
	var locationHash = window.location.hash

	$('body').on('click', '.tabs .btn', function(e) {
		e.preventDefault()

		if (!$(this).hasClass('active')) {
			const $parent = $(this).closest('.tabs_container'),
				activeTab = $(this).data('content'),
				$activeTabContent = $(activeTab),
				level = $(this).data('level')

			$parent.find('.tabs:first .btn').removeClass('active')
			$parent.find('.tab_content.' + level).removeClass('active')

			$(this).addClass('active')
			$activeTabContent.addClass('active')
		}
	})

	if (locationHash && $('.tabs_container').length) {
		const $activeTab = $(`.tabs .btn[data-content="${locationHash}"]`),
			  $activeTabContent = $(locationHash),
			  $parent = $activeTab.closest('.tabs_container'),
			  level = $activeTab.data('level')

		$parent.find('.tabs:first .btn').removeClass('active')
		$parent.find('.tab_content.' + level).removeClass('active')

		$activeTab.addClass('active')
		$activeTabContent.addClass('active')

		$('html, body').stop().animate({ scrollTop: $activeTabContent.offset().top }, 1000)
	}


	// Menu
	$('header .menu_btn').click(e => {
		e.preventDefault()

		$('header .menu_btn').addClass('active')
		$('body').addClass('menu_open')
		$('.menu').addClass('show')
		$('.overlay').fadeIn(250)
	})

	$('.menu .close_btn, .overlay').click(e => {
		e.preventDefault()

		$('header .menu_btn').removeClass('active')
		$('body').removeClass('menu_open')
		$('.menu').removeClass('show')
		$('.overlay').fadeOut(200)
	})


	// Modals
	$('.modal_btn').click(function (e) {
		e.preventDefault()

		let modal = $(this).data('modal')

		$('body').addClass('menu_open')
		$('#' + modal).fadeIn(300)
	})

	$('.modal .close_btn').click(e => {
		e.preventDefault()

		$('body').removeClass('menu_open')
		$('.modal').fadeOut(200)
	})


	// Маска ввода
	const phoneInputs = document.querySelectorAll('input[type=tel]')

	if (phoneInputs) {
		phoneInputs.forEach(el => {
			IMask(el, {
				mask: '+{7} (000) 000-00-00',
				lazy: true
			})
		})
	}


	// Ввод в поля
	$('.form .input').keyup(function() {
		let _self = $(this)

		setTimeout(() => {
			_self.val().length
				? _self.closest('.line').find('.label').addClass('mini')
				: _self.closest('.line').find('.label').removeClass('mini')
		})
	})

	$('.form .input').focus(function() {
		$(this).closest('.line').find('.label').addClass('mini')
	})

	$('.form .input').blur(function() {
		$(this).val().length
			? $(this).closest('.line').find('.label').addClass('mini')
			: $(this).closest('.line').find('.label').removeClass('mini')
	})


	// Страница проекта - Моб. текст
	$('.mob_project_info .description .spoler_btn').click(function(e) {
		e.preventDefault()

		$(this).toggleClass('active')
		$('.mob_project_info .description .text').toggleClass('hide')
	})


	// Fancybox
	Fancybox.bind('[data-fancybox="project"]', {
		compact: false,
        Carousel: {
          Navigation : false
        },
		Thumbs: {
			type: "classic",
		},
		Toolbar: {
			display: {
				left: ['prev', 'infobar', 'next'],
				middle: [],
				right: ['close']
			}
		}
	})


	// Cookie panel
	$('.cookie_panel .close_btn, .cookie_panel .btns .reject_btn, .cookie_panel .btns .agree_btn').click(function(e) {
		e.preventDefault()

		$('.cookie_panel').fadeOut(200)
	})

	$('.cookie_panel .settings_btn').click(function(e) {
		e.preventDefault()

		$('body').addClass('menu_open')

		$('.cookie_panel').fadeOut(200)
		$('.privacy_settings').css('display', 'flex')
	})


	// Mob. cookie btn
	$('.mob_cookie_btn').click(function(e) {
		e.preventDefault()

		$('body').addClass('menu_open')

		$('.mob_cookie_btn').fadeOut(200)
		$('.cookie_panel').fadeIn(300)
	})


	// Privacy settings
	$('.privacy_settings .items .head').click(function(e) {
		if(e.target.nodeName != 'INPUT' && e.target.nodeName != 'LABEL') {
			$(this).toggleClass('active').next().slideToggle(300)
		}
	})


	// Cookie panel
	$('.privacy_settings .close_btn, .privacy_settings .reject_btn, .privacy_settings .agree_btn').click(function(e) {
		e.preventDefault()

		$('body').removeClass('menu_open')

		$('.privacy_settings').fadeOut(200)
	})


	disabledScroll = false
})



window.addEventListener('scroll', e => {
	// Project page - Header
	$(window).scrollTop() > $(window).outerHeight() - $('header').outerHeight()
		? $('header.fixed').removeClass('light')
		: $('header.fixed').addClass('light')


	// Scroll interception
	if ($(window).scrollTop() >= ($('.steps').offset().top - $('.steps').outerHeight() * 0.5)) {
		if(!stepsSliders[0].isEnd) {
			// Stop scroll
			window.scrollTo(0, $('.steps').offset().top - $('.steps').outerHeight() * 0.5)

			// Move slider
			if(!disabledScroll) {
				stepsSliders[0].slideNext(500, true)

				disabledScroll = true

				setTimeout(() => disabledScroll = false, 500)
			}
		}
	} else {
		if(!stepsSliders[0].isBeginning) {
			// Stop scroll
			window.scrollTo(0, $('.steps').offset().top - $('.steps').outerHeight() * 0.5)

			// Move slider
			if(!disabledScroll) {
				stepsSliders[0].slidePrev(500, true)

				disabledScroll = true

				setTimeout(() => disabledScroll = false, 500)
			}
		}
	}
}, { passive: false })